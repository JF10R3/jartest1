import java.util.Scanner;
public class main {

    public static void main(String[] args) {

        Scanner playerInput;
        playerInput = new Scanner (System.in);
        System.out.println("What is your character's name?");
        String playerName = playerInput.nextLine();
        System.out.println("ok " + playerName + ", do you want to start your adventure?");
        System.out.println("1. Yes");
        System.out.println("2. No");
        int gameStart = playerInput.nextInt();


        if (gameStart == 1) {
            System.out.println("__          __  _                          ");
            System.out.println("\\ \\        / / | |                         ");
            System.out.println(" \\ \\  /\\  / /__| | ___ ___  _ __ ___   ___ ");
            System.out.println("  \\ \\/  \\/ / _ \\ |/ __/ _ \\| '_ ` _ \\ / _ \\");
            System.out.println("   \\  /\\  /  __/ | (_| (_) | | | | | |  __/");
            System.out.println("    \\/  \\/ \\___|_|\\___\\___/|_| |_| |_|\\___|");

            System.out.println("do you want to enter the cave to the right of you, or the dark forest to the left?");
            System.out.println("1. Cave");
            System.out.println("2. Forest");
            int rl = playerInput.nextInt();

            if (rl == 1) {
                System.out.println("you walk into the cave, and realise that you have no light source. Do you: ");
                System.out.println("1. Make a fire");
                System.out.println("2. ");




            }

        }else {

            System.out.println("than why are you even here?");
        }




    }

}
